// Converts all SVG icons in icons/ to PNGs of the same size using sharp
const sharp = require('sharp');
const fs = require('fs');
const path = require('path');

const sizes = [16, 32, 48, 128];
const iconsDir = path.join(__dirname, 'icons');

sizes.forEach(size => {
  const svgPath = path.join(iconsDir, `icon${size}.svg`);
  const pngPath = path.join(iconsDir, `icon${size}.png`);
  if (fs.existsSync(svgPath)) {
    sharp(svgPath)
      .png()
      .resize(size, size)
      .toFile(pngPath)
      .then(() => console.log(`Converted ${svgPath} to ${pngPath}`))
      .catch(err => console.error(`Error converting ${svgPath}:`, err));
  } else {
    console.warn(`SVG not found: ${svgPath}`);
  }
});
